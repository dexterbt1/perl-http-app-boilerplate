package Moose::Exception::Legacy;
our $VERSION = '2.1600';

use Moose;
extends 'Moose::Exception';

1;
