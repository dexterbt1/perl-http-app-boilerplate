package Role::Interface;
use Moose::Role;

requires "meth2";

1;
